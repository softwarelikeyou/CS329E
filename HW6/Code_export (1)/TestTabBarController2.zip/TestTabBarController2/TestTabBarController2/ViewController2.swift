//
//  ViewController2.swift
//  TestTabBarController2
//
//  Created by Robert Seitsinger on 8/11/16.
//  Copyright © 2016 Infinity Software. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
