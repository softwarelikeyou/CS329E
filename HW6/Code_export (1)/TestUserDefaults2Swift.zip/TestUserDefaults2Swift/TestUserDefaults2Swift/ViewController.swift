//
//  ViewController.swift
//  TestUserDefaults2Swift
//
//  Created by Robert Seitsinger on 10/3/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtFieldName: UITextField!
    @IBOutlet weak var lblMessage: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Home Screen"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func btnSave(_ sender: AnyObject) {
        Config.setName(txtFieldName.text!)
        self.lblMessage.text = "Name saved"
    }
    
}

