//
//  Config.swift
//  TestUserDefaults2Swift
//
//  Created by Robert Seitsinger on 10/3/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation

class Config: NSObject {
    // Define keys for the values to store
    fileprivate static let kUserIdKey = "userId"
    fileprivate static let kNameKey = "name"
    
    class func setUserId(_ userId:Int) {
        UserDefaults.standard.set(userId, forKey: kUserIdKey)
        UserDefaults.standard.synchronize()
    }
    class func setName(_ name:String) {
        UserDefaults.standard.set(name, forKey: kNameKey)
        UserDefaults.standard.synchronize()
    }
    
    class func userId() -> Int {
        return UserDefaults.standard.integer(forKey: kUserIdKey)
    }
    class func name() -> String {
        return UserDefaults.standard.object(forKey: kNameKey) as! String
    }
}
