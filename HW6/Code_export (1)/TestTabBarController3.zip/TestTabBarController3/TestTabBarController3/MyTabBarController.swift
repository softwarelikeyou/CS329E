//
//  MyTabBarController.swift
//  TestTabBarController3
//
//  Created by Robert Seitsinger on 10/4/16.
//  Copyright © 2016 Infinity Software. All rights reserved.
//

///////////////////////////////////////////////////////////////////////
// This sample app creates the tab bar programmatically.
// For some this can be easier than doing it through the storyboard.
///////////////////////////////////////////////////////////////////////

import UIKit

class MyTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegate = self
        self.tabBar.isTranslucent = false
        
        self.createTabs()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    fileprivate func createTabs() {
        let storyboard = UIStoryboard(name: "Main", bundle:nil)
        
        let vc1 = storyboard.instantiateViewController(withIdentifier: "vc1") as? ViewController1
        let vc2 = storyboard.instantiateViewController(withIdentifier: "vc2") as? ViewController2
        let vc3 = storyboard.instantiateViewController(withIdentifier: "vc3") as? ViewController3
        let vc4 = storyboard.instantiateViewController(withIdentifier: "vc4") as? ViewController4
        
        // Get each tab's image from the Assets.xcassets file.
        let image1 = UIImage(named: "tab1")
        let image2 = UIImage(named: "tab2")
        let image3 = UIImage(named: "tab3")
        let image4 = UIImage(named: "tab4")
        
        // Set each tab's item attributes.
        vc1!.tabBarItem = UITabBarItem(
            title: "Tab 1",
            image: image1,
            tag: 1)
        vc2!.tabBarItem = UITabBarItem(
            title: "Tab 2",
            image: image2,
            tag: 2)
        vc3!.tabBarItem = UITabBarItem(
            title: "Tab 3",
            image: image3,
            tag: 3)
        vc4!.tabBarItem = UITabBarItem(
            title: "Tab 4",
            image: image4,
            tag: 4)

        // Wrap the view controllers in their own nav controllers.
        let nc1 = UINavigationController(rootViewController: vc1!)
        let nc2 = UINavigationController(rootViewController: vc2!)
        let nc3 = UINavigationController(rootViewController: vc3!)
        let nc4 = UINavigationController(rootViewController: vc4!)
        
        // Create the array of controllers that make up the tab bar items.
        let controllers:[UIViewController] = [nc1, nc2, nc3, nc4]
        self.viewControllers = controllers
    }
}

extension MyTabBarController: UITabBarControllerDelegate {
    // Indicates which tab bar item was tapped.
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        print("====>>>   didSelectItem. item.tag = \(item.tag)")
    }
}
