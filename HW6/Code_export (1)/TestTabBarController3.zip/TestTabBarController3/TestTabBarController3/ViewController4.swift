//
//  ViewController4.swift
//  TestTabBarController3
//
//  Created by Robert Seitsinger on 10/4/16.
//  Copyright © 2016 Infinity Software. All rights reserved.
//

import UIKit

class ViewController4: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Tab Bar Demo"
        print("ViewController4: viewDidLoad")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("ViewController4: viewWillAppear")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
