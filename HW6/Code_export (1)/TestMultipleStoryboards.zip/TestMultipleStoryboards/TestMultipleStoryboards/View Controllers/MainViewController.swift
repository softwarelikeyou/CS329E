//
//  MainViewController.swift
//  TestMultipleStoryboards
//
//  Created by Robert Seitsinger on 10/8/17.
//  Copyright © 2017 Summer Moon Solutions. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Main"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnShowDetailAction(_ sender: Any) {
        // Manually instantiate the detail view controller that lives in the Joe storyboard and present it.
        let storyboard = UIStoryboard(name: "Joe", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DetailVC") as! DetailViewController
        // Pass info to the target view controller.
        vc.config(name: "Sam Smith", address: "1 Main Street, Austin, TX")
        // Wrap this manually presented view controller in a navigation controller.
        let nc = UINavigationController(rootViewController: vc)
        // Show it to the user.
        present(nc, animated: true, completion: nil)
    }
}
