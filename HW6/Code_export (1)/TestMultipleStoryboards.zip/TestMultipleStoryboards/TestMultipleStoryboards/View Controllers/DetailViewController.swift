//
//  DetailViewController.swift
//  TestMultipleStoryboards
//
//  Created by Robert Seitsinger on 10/8/17.
//  Copyright © 2017 Summer Moon Solutions. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    
    private var name: String!
    private var address: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Detail"
        
        lblName.text = name
        lblAddress.text = address
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func config(name: String, address: String) {
        self.name = name
        self.address = address
    }

    @IBAction func btnDismissAction(_ sender: Any) {
        // Dismiss this view controller and go back to the view controller that presented it.
        self.dismiss(animated: true, completion: nil)
    }
}
