//
//  main.swift
//  TestUserDefaults
//
//  Created by Robert Seitsinger on 9/29/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation

// Define keys for the values to store
let kUserIdKey = "userId"
let kTotalKey = "total"
let kNameKey = "name"

// Define the values to store
let userId = 900
let total = 1275.55
let name = "University of Texas"

// Get a reference to the global user defaults object
let defaults = UserDefaults.standard

// Store various values
defaults.set(userId, forKey: kUserIdKey)
defaults.set(total, forKey: kTotalKey)
defaults.set(name, forKey: kNameKey)

defaults.synchronize()  // force the write to the device

// Retrieve the previously stored values
let retrievedUserId = defaults.integer(forKey: kUserIdKey)
let retrievedTotal = defaults.double(forKey: kTotalKey)
let retrievedName = defaults.object(forKey: kNameKey)

print("UserId: \(retrievedUserId)");
print("Total: \(retrievedTotal)");
print("Name: \(retrievedName!)");
