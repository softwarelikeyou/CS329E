
import UIKit

class MyPageViewController: UIPageViewController, UIPageViewControllerDataSource {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        dataSource = self
        
        view.backgroundColor = UIColor.lightGray
        
        let viewController = MyViewController()
        viewController.wonder = wonders.first
        
        let viewControllers = [viewController]
        setViewControllers(viewControllers, direction: .forward, animated: true, completion: nil)
    }

    let wonders = ["wonders1", "wonders2", "wonders2", "wonders4", "wonders5", "wonders6", "wonders7"]
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerBefore viewController: UIViewController) -> UIViewController? {
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerAfter viewController: UIViewController) -> UIViewController? {
        return nil
    }
}
