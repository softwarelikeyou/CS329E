//
//  PersonViewController.swift
//  ThomasCourtney-hw3
//
//  Created by Courtney Thomas on 9/24/17.
//  Copyright © 2017 CS329E. All rights reserved.
//

import UIKit


class PersonViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
                // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var person = Person(firstName: "", lastName: "", age: 0, city: "")
    
    @IBOutlet weak var firstName: UILabel!
    @IBOutlet weak var lastName: UILabel!
    @IBOutlet weak var age: UILabel!
    @IBOutlet weak var city: UILabel!
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //firstName.text = person.firstName
        //lastName.text = person.lastName
       // age.text = String(describing: person.age)
        //city.text = person.city
        print(segue.identifier)
    }
    

}
