//
//  PeopleTableViewController.swift
//  ThomasCourtney-hw3
//
//  Created by Courtney Thomas on 9/24/17.
//  Copyright © 2017 CS329E. All rights reserved.
//

import UIKit

class PeopleTableViewController: UITableViewController{

    override func viewDidLoad() {
        super.viewDidLoad()
        createDataModel()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return people.count
    }
    
    private var people = [Person]()
    private func createDataModel() {
        var personOne = Person(firstName: "Bob", lastName: "Carpenter", age: 35, city: "Austin")
        var personTwo = Person(firstName: "John", lastName: "Jones", age: 8, city: "Boston")
        var personThree = Person(firstName: "Led", lastName: "Zepplin", age: 73, city: "Paris")
        var personFour = Person(firstName: "Sam", lastName: "Smith", age: 34, city: "Sydney")
        var personFive = Person(firstName: "June", lastName: "Johnson", age: 12, city: "Vienna")
        var personSix = Person(firstName: "Allison", lastName: "Atwater", age: 21, city: "Vienna")
        var personSeven = Person(firstName: "Donald", lastName: "Trump", age: 56, city: "Munich")
        var personEight = Person(firstName: "Hillary", lastName: "Clinton", age: 69, city: "Brussels")
        var personNine = Person(firstName: "Barrack", lastName: "Obama", age: 53, city: "Tokyo")
        var personTen = Person(firstName: "Teddy", lastName: "Roosevelt", age: 70, city: "Shanghai")
        
        people = [personOne, personTwo, personThree, personFour, personFour, personFive, personSix, personSeven, personEight, personNine, personTen]

    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        let row = indexPath.row
        cell.textLabel?.text = people[row].firstName
        cell.detailTextLabel?.text = people[row].lastName
    
        return cell
    }
    
    /*
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //let firstName: String = people[(tableView.indexPathForSelectedRow?.row)!].firstName!
        //let lastName: String = people[(tableView.indexPathForSelectedRow?.row)!].lastName!
       // let age: Int = people[(tableView.indexPathForSelectedRow?.row)!].age!
       // let city: String = people[(tableView.indexPathForSelectedRow?.row)!].city!
        let selected: Person = people[(tableView.indexPathForSelectedRow?.row)!]
        segue.destination as! PersonViewController
        d.person = selected
        
 
        
    }
 */
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */


    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        let selected: Person = people[(tableView.indexPathForSelectedRow?.row)!]
        let d: PersonViewController = segue.destination as! PersonViewController
        d.person = selected
        // Pass the selected object to the new view controller.
    }


}

